<?php
$hostname = "localhost";
$username = "root";
$password = "";
$db = "rah";
$dbconnect=mysqli_connect($hostname,$username,$password,$db);
if ($dbconnect->connect_error) {
    die("Database connection failed: " . $dbconnect->connect_error);
}
$q = "SELECT * FROM `place`";
$query = mysqli_query($dbconnect, $q)
   or die (mysqli_error($dbconnect));
?>
<!DOCTYPE HTML>
<html>
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" type="text/css" href="style.css">
        <link rel="stylesheet" type="text/css" href="038%20Grid.css">
        <link rel='stylesheet' type='text/css' href='https://cdn.fontcdn.ir/Font/Persian/Nazanin/Nazanin.css'>
        <link rel="stylesheet" type="text/css" href="persianDatepicker-master/css/persianDatepicker-default.css">
        <script src="persianDatepicker-master/js/jquery-1.10.1.min.js"></script>
        <script src="persianDatepicker-master/js/persianDatepicker.min.js"></script>
	
        <title>سامانه مدیریت جلسات ویدئو کنفرانسی</title>
    </head>
    <body>
        <div class="row">
            <nav>
                <div class="row">
					<div class="col span-1-of-5 box">
						<a class="button" href="logout.php"><b>خروج</b></a>
					</div>
                    <div class="col span-1-of-5 box">
                        <a class="button" href="showConfs.php"><b>کنفرانس ها</b></a>
                    </div>
					<div class="col span-1-of-5 box">
						<a class="button" href="javascript:(function(){document.getElementById('formPlace').style.display='block';})()"><b>محل برگزاری</b></a>
					</div>
                    <div class="col span-1-of-5 box">
                        <a class="button" href="javascript:(function(){document.getElementById('formGuest').style.display='block';})()"><b>فرم مهمان</b></a>
                    </div>
                    <div class="col span-1-of-5 box">
                        <a class="button" href="javascript:(function(){document.getElementById('formHost').style.display='block';})()"><b>فرم میزبان</b></a>
                    </div>
                </div>
            </nav>
        </div>
        <div class="row" id="formPlace" style="display:none">
			<h2>محل مورد نظر را وارد کنید</h2>
			<form class="form" method="post" action="addPlace.php">
				<div class="row">
					<label class="label" for="nameOfPlace"><b>نام محل</b>
					<input type="text" placeholder="نام محل را وارد کنید" name="nameOfPlace" required>
				</div>
				<div class="row">
					<div class="col span-1-of-2">
						<input type="reset" name="reset" value="انصراف">
					</div>
					<div class="col span-1-of-2">
						<input type="submit" name="submit" value="ثبت">
					</div>
				</div>
				</div>
			</form>
		</div>

        <div class="row" id="formHost" style="display:none">
            <h2>فرم میزبان</h2>
            <form class="form" method="post" action="addHostConf.php">
                <div class="row">
                    <label class="label" for="requestNumber"><b>شماره درخواست</b></label>
                    <input type="text" placeholder="شماره درخواست را وارد کنید" name="requestNumber" required>
                </div>
				<div class="row">
					<div class="col span-1-of-2">
                        <label class="label" for="startDate"><b>تاریخ برگزاری</b></label>
                        <input type="text" placeholder="تاریخ برگزاری را وارد کنید" id="pdpDefault" pdp-id="pdp-8958408" class="pdp-el" name="startDate" required>
                    </div>
					<div class="col span-1-of-2">
                       <label class="label" for="requestDate"><b>تاریخ درخواست</b></label>
                       <input type="text" placeholder="تاریخ را وارد کنید" id="pdpDefault" pdp-id="pdp-8958408" class="pdp-el" name="requestDate" required>
                    </div>
                </div>
                <div class="row">
                    <div class="col span-1-of-2">
                        <label class="label" for="place"><b>مکان برگزاری</b></label>
						<select name="place" required>
						<?php
							while($row = mysqli_fetch_array($query)){
							//echo $row[0];
							//echo $row[1];
							echo '<option value="' .$row[1].'">'.$row[1].'</option>';
								
							}
							
						?>
						</select>
                    </div>
                    <div class="col span-1-of-2">
                        <label class="label" for="topic"><b>موضوع جلسه</b></label>
                        <input type="text" placeholder="موضوع جلسه را وارد کنید" name="topic" required>
                    </div>
                </div>
                <div class="row">
                    <div class="col span-1-of-2">
                        <label class="label" for="hostManager"><b>رئیس جلسه</b></label>
                        <input type="text" placeholder="نام رئیس جلسه را وارد کنید" name="hostManager" required>
                    </div>
                    <div class="col span-1-of-2">
                        <label class="label" for="host"><b>میزبان جلسه</b></label>
                        <input type="text" placeholder="میزبان جلسه را وارد کنید" name="host" required>
                    </div>
                </div>
                <div class="row">
                    <div class="col span-1-of-2">
                        <label class="label" for="endTime"><b>زمان پایان جلسه</b></label>
                        <input type="time" name="endTime" required>
                    </div>
                    <div class="col span-1-of-2">
                        <label class="label" for="startTime"><b>زمان شروع جلسه</b></label>
                        <input type="time" name="startTime" required>
                    </div>
                </div>
                <div class="row">
                    <div class="col span-1-of-2">
                        <label class="label" for="participators"><b>مدعوین</b></label>
                        <textarea name="participators"></textarea>
                    </div>
                    <div class="col span-1-of-2">
                        <label class="label" for="supporter"><b>رابط برگزارکننده</b></label>
                        <input type="text" placeholder="نام رابط را وارد کنید" name="supporter" required>
                    </div>
                </div>
                <div class="row">
                    <div class="col span-1-of-2">
                        <input type="reset" name="reset" value="انصراف">
                    </div>
                    <div class="col span-1-of-2">
                        <input type="submit" name="submit" value="ثبت">
                    </div>  
                </div>
            </form>
        </div>
        
        <div class="row" id="formGuest" style="display:none">
            <h2>فرم مهمان</h2>
            <form class="form" method="post" action="addGuestConf.php">
                <div class="row">
                        <label class="label" for="requestNumber"><b>شماره درخواست</b></label>
                        <input type="text" placeholder="شماره درخواست را وارد کنید" name="requestNumber" required>
                </div>
				<div class="row">
					<div class="col span-1-of-2">
                        <label class="label" for="startDate"><b>تاریخ برگزاری</b></label>
                        <input type="text" placeholder="تاریخ برگزاری را وارد کنید" id="pdpDefault" pdp-id="pdp-8958408" class="pdp-el" name="startDate" required>
                    </div>  
					<div class="col span-1-of-2">
                       <label class="label" for="requestDate"><b>تاریخ درخواست</b></label>
                       <input type="text" placeholder="تاریخ را وارد کنید" id="pdpDefault" pdp-id="pdp-8958408" class="pdp-el" name="requestDate" required>
                    </div>      
                </div>
                <div class="row">
                    <div class="col span-1-of-2">
                        <label class="label" for="place"><b>مکان برگزاری</b></label>
						<select name="place" required>
						<?php
							$q1 = "SELECT * FROM `place`";
							$query1 = mysqli_query($dbconnect, $q1)
								or die (mysqli_error($dbconnect));
							while($row1 = mysqli_fetch_array($query1)){
							//echo $row[0];
							//echo $row[1];
							echo '<option value="' .$row1[1].'">'.$row1[1].'</option>';
								
							}	
						?>
						</select>
                    </div>
                    <div class="col span-1-of-2">
                        <label class="label" for="topic"><b>موضوع جلسه</b></label>
                        <input type="text" placeholder="موضوع جلسه را وارد کنید" name="topic" required>
                    </div>
                </div>
                <div class="row">
                    <div class="col span-1-of-2">
                        <label class="label" for="hostManager"><b>رئیس جلسه</b></label>
                        <input type="text" placeholder="رئیس جلسه را وارد کنید" name="hostManager" required>
                    </div>
                    <div class="col span-1-of-2">
                        <label class="label" for="host"><b>میزبان جلسه</b></label>
                        <input type="text" placeholder="میزبان جلسه را وارد کنید" name="host" required>
                    </div> 
                </div>
                <div class="row">
                    <div class="col span-1-of-2">
                        <label class="label" for="endTime"><b>زمان پایان جلسه</b></label>
                        <input type="time" name="endTime" required>
                    </div>
                    <div class="col span-1-of-2">
                        <label class="label" for="startTime"><b>زمان شروع جلسه</b></label>
                        <input type="time" name="startTime" required>
                    </div>
                    
                </div>
                <div class="row">
                    <div class="col span-1-of-2">
                        <label class="label" for="supTel"><b>شماره تماس رابط</b></label>
                        <input type="text"  placeholder="شماره تماس را وارد کنید" name="supTel" required>
                    </div>
                    <div class="col span-1-of-2">
                        <label class="label" for="supporter"><b>رابط برگزارکننده</b></label>
                        <input type="text" placeholder="نام رابط را وارد کنید" name="supporter" required>
                    </div>      
                </div>
                <div class="row">
                    <div class="col span-1-of-3">
                        <label class="label" for="platDescription"><b>مشخصات فنی نرم افزار</b></label>
                        <textarea name="platDescription"></textarea>
                    </div>
                    <div class="col span-1-of-3">
                        <label class="label" for="platformLink"><b>لینک نرم افزار</b></label>
                        <input type="text"  placeholder="لینک را وارد کنید" name="platformLink" required>
                    </div>
                    <div class="col span-1-of-3">
                        <label class="label" for="platformName"><b>نام نرم افزار</b></label>
                        <input type="text" placeholder="نام نرم افزار را وارد کنید" name="platformName" required>
                    </div>
                </div>
                <div class="row">
                    <div class="col span-1-of-2">
                        <input type="reset" name="reset" value="انصراف">
                    </div>
                    <div class="col span-1-of-2">
                        <input type="submit" name="submit" value="ثبت">
                    </div>  
                </div>
            </form>
        </div>
    </body>
    <script>
        $(function () {
            //usage
            $(".usage").persianDatepicker();

            //themes
            $("#pdpDefault").persianDatepicker({ alwaysShow: true, });
            $("#pdpLatoja").persianDatepicker({ theme: "latoja", alwaysShow: true, });
            $("#pdpLightorang").persianDatepicker({ theme: "lightorang", alwaysShow: true, });
            $("#pdpMelon").persianDatepicker({ theme: "melon", alwaysShow: true, });
            $("#pdpDark").persianDatepicker({ theme: "dark", alwaysShow: true, });

            //size
            $("#pdpSmall").persianDatepicker({ cellWidth: 14, cellHeight: 12, fontSize: 8 });
            $("#pdpBig").persianDatepicker({ cellWidth: 78, cellHeight: 60, fontSize: 18 });

            //formatting
            $("#pdpF1").persianDatepicker({ formatDate: "YYYY/MM/DD 0h:0m:0s:ms" });
            $("#pdpF2").persianDatepicker({ formatDate: "YYYY-0M-0D" });
            $("#pdpF3").persianDatepicker({ formatDate: "YYYY-NM-DW|ND", isRTL: !0 });

            //startDate & endDate
            $("#pdpStartEnd").persianDatepicker({ startDate: "1394/11/12", endDate: "1395/5/5" });
            $("#pdpStartToday").persianDatepicker({ startDate: "today", endDate: "1410/11/5" });
            $("#pdpEndToday").persianDatepicker({ startDate: "1397/11/12", endDate: "today" });

            //selectedBefor & selectedDate
            $("#pdpSelectedDate").persianDatepicker({ selectedDate: "1404/1/1", alwaysShow: !0 });
            $("#pdpSelectedBefore").persianDatepicker({ selectedBefore: !0 });
            $("#pdpSelectedBoth").persianDatepicker({ selectedBefore: !0, selectedDate: "1395/5/5" });

            //jdate & gdate attributes
            $("#pdp-data-jdate").persianDatepicker({
                onSelect: function () {
                    alert($("#pdp-data-jdate").attr("data-gdate"));
                }
            });
            $("#pdp-data-gdate").persianDatepicker({
                showGregorianDate: true,
                onSelect: function () {
                    alert($("#pdp-data-gdate").attr("data-jdate"));
                }
            });


            //Gregorian date
            $("#pdpGregorian").persianDatepicker({ showGregorianDate: true });

            // jDateFuctions
            // var jdf = new jDateFunctions();
            // var pd = new persianDate();
            // $("#pdpjdf-1").persianDatepicker({
            //     onSelect: function () {
            //         $("#pdpjdf-1").val(jdf.getJulianDayFromPersian(pd.parse($("#pdpjdf-1").val())));
            //         $("#pdpjdf-2").val(jdf.getLastDayOfPersianMonth(pd.parse($("#pdpjdf-1").val())));
            //         $("#pdpjdf-3").val(jdf.getPCalendarDate($("#pdpjdf-1").val()));
            //     }
            // });


             //convert jalali date to miladi
            // $("#year, #month, #day").on("change", function () {
            //     $("#month").val() > 6 ? $("#day-31").hide() : $("#day-31").show();;
            //     showConverted();
            // });

            // $("#year").keyup(showConverted);
            //
            // function showConverted() {
            //     try{
            //         var pd = new persianDate();
            //         pd.year = parseInt($("#year").val());
            //         pd.month = parseInt($("#month").val());
            //         pd.date = parseInt($("#day").val());
            //
            //         var jdf = new jDateFunctions();
            //         $("#converted").html("Gregorian :  " + jdf.getGDate(pd)._toString("YYYY/MM/DD") + "     [" + jdf.getGDate(pd) + "]<br />Julian:  " + jdf.getJulianDayFromPersian(pd));
            //
            //     } catch (e) {
            //         $("#converted").html("Enter the year correctly!");
            //     }
            // }


            //startDate is tomarrow
            var p = new persianDate();
            $("#pdpStartDateTomarrow").persianDatepicker({ startDate: p.now().addDay(1).toString("YYYY/MM/DD"), endDate: p.now().addDay(4).toString("YYYY/MM/DD") });


        });
    
    </script>
    <script>
            $("#pdpDefault, .pdp-el").persianDatepicker();
        </script>
</html>

<?php ?>