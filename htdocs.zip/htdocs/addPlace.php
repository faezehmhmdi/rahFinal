<?php
$hostname = "localhost";
$username = "root";
$password = "";
$db = "rah";
$dbconnect=mysqli_connect($hostname,$username,$password,$db);
if ($dbconnect->connect_error) {
    die("Database connection failed: " . $dbconnect->connect_error);
}

$name = $_POST['nameOfPlace'];
$isEmp = 1;
$q = "SELECT addPlace('".$name. "','" .$isEmp."')";
$query = mysqli_query($dbconnect, $q)
   or die (mysqli_error($dbconnect));
   while ($row = mysqli_fetch_array($query)) {
    if($row[0] == "Place added") {
        echo '<script>alert("محل با موفقیت افزوده شد")</script>';
		header('Refresh: 1; URL = mainPage.php');
		exit;
    }
    else{
        echo '<script>alert("محل از قبل اضافه شده است")</script>';
		header('Refresh: 1; URL = mainPage.php');
		exit;
    }
   }
?>