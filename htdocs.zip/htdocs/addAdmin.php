<?php
$hostname = "localhost";
$username = "root";
$password = "";
$db = "rah";
$dbconnect=mysqli_connect($hostname,$username,$password,$db);
if ($dbconnect->connect_error) {
    die("Database connection failed: " . $dbconnect->connect_error);
}

$userName = $_POST['usernameA'];
var_dump($userName);
$pass = $_POST['passA'];
var_dump($pass);
$q = "SELECT addAdmin('".$userName. "','" .$pass."');";
$query = mysqli_query($dbconnect, $q)
   or die (mysqli_error($dbconnect));
while ($row = mysqli_fetch_array($query)) {
    if($row[0] != 'Admin account saved') {
        echo $row[0];
    }
    else{
        include('adminLogin.html');
		exit;
    }
}