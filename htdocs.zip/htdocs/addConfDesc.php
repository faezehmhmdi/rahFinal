<?php
$hostname = "localhost";
$username = "root";
$password = "";
$db = "rah";
$dbconnect=mysqli_connect($hostname,$username,$password,$db);
if ($dbconnect->connect_error) {
    die("Database connection failed: " . $dbconnect->connect_error);
}

function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
$id = $_GET['id'];
$desc = test_input($_GET['desc']);
if (empty($desc)){
	$desc = null;
}

  $q = "SELECT addConfDescription('".$id. "','" .$desc."');";
  $query = mysqli_query($dbconnect, $q)
        or die (mysqli_error($dbconnect));
	
    while ($row = mysqli_fetch_array($query)) {
		header('Refresh: 1; URL = showConfs.php');
        if ($row[0] == "Conf with id doesn\'t exist"){
			echo '<script>alert("اشتباهی رخ داده است");</script>';
			header('Refresh: 1; URL = mainPage.php');
		}
		else {
			echo '<script>alert("شرح با موفقیت افزوده شد");</script>';
			header('Refresh: 1; URL = mainPage.php');
		}
    }
?>