<?php
session_start();
$hostname = "localhost";
$username = "root";
$password = "";
$db = "rah";
$dbconnect=mysqli_connect($hostname,$username,$password,$db);
if ($dbconnect->connect_error) {
    die("Database connection failed: " . $dbconnect->connect_error);
}
$userName = $_POST['username'];
$_SESSION['username'] = $userName;
$pass = $_POST['pass'];
$_SESSION['pass'] = $pass;
$q = "SELECT login('".$userName. "','" .$pass."');";
$query = mysqli_query($dbconnect, $q)
   or die (mysqli_error($dbconnect));
while ($row = mysqli_fetch_array($query)) {
    if($row[0] != 'Logged in') {
		echo '<script>alert("رمز یا نام کاربری اشتباه")</script>';
		header('Refresh: 2; URL = adminLogin.html');
    }
    else{
		$_SESSION['valid'] = true;
        header("Location: mainPage.php");
		exit;
    }
}
?>